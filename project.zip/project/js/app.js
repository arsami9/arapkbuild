'use strict';

/* =========================================================
   ক্যালকুলেটর ইঞ্জিন (DOM ছাড়া, তাই আলাদাভাবে টেস্ট করা যায়)
   ========================================================= */
class Calculator {
  constructor() {
    this.history = [];
    this.clear();
  }

  clear() {
    this.tokens = [];          // [সংখ্যা, অপারেটর, সংখ্যা, ...]
    this.current = '';         // যে সংখ্যাটি এখন লেখা হচ্ছে
    this.justEvaluated = false;
    this.lastResult = null;
    this.error = null;
  }

  _guard() {
    if (this.error) this.clear();
  }

  // আগের ফলাফলকে নতুন হিসাবের শুরু হিসেবে নেওয়া
  _resume() {
    if (this.justEvaluated) {
      this.tokens = [];
      this.current = String(this.lastResult);
      this.justEvaluated = false;
    }
  }

  inputDigit(d) {
    this._guard();
    if (this.justEvaluated) {
      this.tokens = [];
      this.current = '';
      this.justEvaluated = false;
    }
    if (this.current.replace(/[-.]/g, '').length >= 15) return;
    if (this.current === '0') this.current = d;
    else if (this.current === '-0') this.current = '-' + d;
    else this.current += d;
  }

  inputDot() {
    this._guard();
    if (this.justEvaluated) {
      this.tokens = [];
      this.current = '';
      this.justEvaluated = false;
    }
    if (this.current.includes('.')) return;
    if (this.current === '') this.current = '0.';
    else if (this.current === '-') this.current = '-0.';
    else this.current += '.';
  }

  inputOperator(op) {
    this._guard();
    this._resume();
    if (this.current === '' || this.current === '-') {
      // অপারেটর পরপর দিলে শেষটা বদলে যাবে
      if (this.tokens.length) this.tokens[this.tokens.length - 1] = op;
      return;
    }
    this.tokens.push(Calculator._clean(this.current), op);
    this.current = '';
  }

  toggleSign() {
    this._guard();
    this._resume();
    if (this.current === '') this.current = '-';
    else if (this.current.startsWith('-')) this.current = this.current.slice(1);
    else this.current = '-' + this.current;
  }

  percent() {
    this._guard();
    this._resume();
    if (this.current === '' || this.current === '-') return;
    const v = parseFloat(this.current) / 100;
    this.current = String(parseFloat(v.toPrecision(12)));
  }

  backspace() {
    this._guard();
    if (this.justEvaluated) {
      this.clear();
      return;
    }
    if (this.current !== '') {
      this.current = this.current.slice(0, -1);
      if (this.current === '-') this.current = '';
    } else if (this.tokens.length) {
      this.tokens.pop();                 // অপারেটর সরানো
      this.current = this.tokens.pop() || '';  // আগের সংখ্যা আবার এডিটযোগ্য
    }
  }

  equals() {
    if (this.error || this.justEvaluated) return;
    const tokens = this.tokens.slice();
    if (this.current !== '' && this.current !== '-') {
      tokens.push(Calculator._clean(this.current));
    } else if (tokens.length && this._isOperator(tokens[tokens.length - 1])) {
      tokens.pop(); // ঝুলে থাকা অপারেটর বাদ
    }
    if (tokens.length === 0) return;
    if (tokens.length === 1) {
      // শুধু একটি সংখ্যা: কিছু করার নেই
      return;
    }

    const exprText = tokens.map((t, i) => (i % 2 === 0 ? Calculator.formatTyping(t) : t)).join(' ');

    try {
      const value = Calculator.evaluate(tokens);
      this.lastResult = value;
      this.history.unshift({ expr: exprText, result: Calculator.format(value) });
      if (this.history.length > 30) this.history.pop();
      this.tokens = [];
      this.current = '';
      this.justEvaluated = true;
      this.finishedExpr = exprText + ' =';
    } catch (e) {
      this.clear();
      this.error = e.message === 'DIV0'
        ? 'শূন্য দিয়ে ভাগ করা যায় না'
        : 'ভুল হিসাব';
    }
  }

  _isOperator(t) {
    return t === '+' || t === '−' || t === '×' || t === '÷';
  }

  /* ---------- ডিসপ্লে টেক্সট ---------- */
  get expression() {
    if (this.error) return '';
    if (this.justEvaluated) return this.finishedExpr;
    const parts = this.tokens.map((t, i) => (i % 2 === 0 ? Calculator.formatTyping(t) : t));
    if (this.current !== '') parts.push(Calculator.formatTyping(this.current));
    return parts.join(' ');
  }

  get main() {
    if (this.error) return this.error;
    if (this.justEvaluated) return Calculator.format(this.lastResult);
    if (this.current !== '') return Calculator.formatTyping(this.current);
    if (this.tokens.length) return Calculator.formatTyping(this.tokens[this.tokens.length - 2]);
    return '0';
  }

  /* ---------- স্ট্যাটিক হেল্পার ---------- */
  static _clean(s) {
    // "5." -> "5", "-" বা "" যেন না থাকে
    if (s.endsWith('.')) s = s.slice(0, -1);
    return s === '' || s === '-' ? '0' : s;
  }

  // অপারেটর প্রাধান্য মেনে হিসাব (eval ব্যবহার না করে)
  static evaluate(tokens) {
    const values = [];
    const ops = [];
    tokens.forEach((t, i) => (i % 2 === 0 ? values.push(parseFloat(t)) : ops.push(t)));

    // ধাপ ১: × এবং ÷
    const v2 = [values[0]];
    const o2 = [];
    for (let i = 0; i < ops.length; i++) {
      const op = ops[i];
      const next = values[i + 1];
      if (op === '×') {
        v2[v2.length - 1] *= next;
      } else if (op === '÷') {
        if (next === 0) throw new Error('DIV0');
        v2[v2.length - 1] /= next;
      } else {
        o2.push(op);
        v2.push(next);
      }
    }

    // ধাপ ২: + এবং −
    let result = v2[0];
    for (let i = 0; i < o2.length; i++) {
      result = o2[i] === '+' ? result + v2[i + 1] : result - v2[i + 1];
    }

    if (!isFinite(result)) throw new Error('INVALID');
    return parseFloat(result.toPrecision(12)); // 0.1+0.2 জাতীয় সমস্যা এড়াতে
  }

  static format(n) {
    if (!isFinite(n)) return 'ভুল হিসাব';
    const abs = Math.abs(n);
    if (abs !== 0 && (abs >= 1e15 || abs < 1e-9)) {
      return n.toExponential(6).replace(/\.?0+e/, 'e');
    }
    return n.toLocaleString('en-US', { maximumFractionDigits: 12 });
  }

  // লেখার সময় (যেমন "1234." বা "0.50") কমা যোগ করা, কিন্তু অংশ ঠিক রাখা
  static formatTyping(s) {
    if (/e/i.test(s)) return String(Calculator.format(parseFloat(s)));
    const neg = s.startsWith('-');
    const body = neg ? s.slice(1) : s;
    const [int, frac] = body.split('.');
    const withCommas = (int || '0').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + withCommas + (frac !== undefined ? '.' + frac : '');
  }
}

/* টেস্টের জন্য এক্সপোর্ট (ব্রাউজারে এটা চলবে না) */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Calculator;
}

/* =========================================================
   ইউজার ইন্টারফেস
   ========================================================= */
function initApp() {
  const calc = new Calculator();

  const exprEl = document.getElementById('expression');
  const resultEl = document.getElementById('result');
  const keypad = document.getElementById('keypad');
  const historyPanel = document.getElementById('historyPanel');
  const historyToggle = document.getElementById('historyToggle');
  const historyList = document.getElementById('historyList');
  const historyEmpty = document.getElementById('historyEmpty');
  const historyClear = document.getElementById('historyClear');
  const themeToggle = document.getElementById('themeToggle');

  const HISTORY_KEY = 'calc.history';
  const THEME_KEY = 'calc.theme';

  /* ---------- স্টোরেজ (প্রাইভেট মোডে ফেল করলেও সমস্যা নেই) ---------- */
  function load(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, value); } catch (e) { /* উপেক্ষা */ }
  }

  /* ---------- থিম ---------- */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
  }
  const savedTheme = load(THEME_KEY);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(savedTheme || (prefersDark ? 'dark' : 'light'));

  themeToggle.addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    save(THEME_KEY, next);
  });

  /* ---------- হিস্ট্রি লোড ---------- */
  try {
    const stored = JSON.parse(load(HISTORY_KEY) || '[]');
    if (Array.isArray(stored)) calc.history = stored.slice(0, 30);
  } catch (e) { /* উপেক্ষা */ }

  /* ---------- রেন্ডার ---------- */
  function render() {
    exprEl.textContent = calc.expression;
    const text = calc.main;
    resultEl.textContent = text;

    resultEl.classList.toggle('error', Boolean(calc.error));
    resultEl.classList.toggle('md', !calc.error && text.length > 10 && text.length <= 14);
    resultEl.classList.toggle('sm', !calc.error && text.length > 14);

    renderHistory();
  }

  function renderHistory() {
    historyList.innerHTML = '';
    calc.history.forEach((item) => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'history-item';
      btn.innerHTML = '<span class="h-expr"></span><span class="h-res"></span>';
      btn.querySelector('.h-expr').textContent = item.expr + ' =';
      btn.querySelector('.h-res').textContent = item.result;
      btn.addEventListener('click', () => {
        // ফলাফলকে নতুন হিসাবের শুরু হিসেবে নেওয়া
        calc.clear();
        calc.current = item.result.replace(/,/g, '');
        setHistoryOpen(false);
        render();
      });
      li.appendChild(btn);
      historyList.appendChild(li);
    });
    historyEmpty.hidden = calc.history.length > 0;
  }

  function setHistoryOpen(open) {
    historyPanel.hidden = !open;
    historyToggle.setAttribute('aria-expanded', String(open));
  }

  historyToggle.addEventListener('click', () => setHistoryOpen(historyPanel.hidden));
  historyClear.addEventListener('click', () => {
    calc.history = [];
    save(HISTORY_KEY, '[]');
    render();
  });

  /* ---------- অ্যাকশন ---------- */
  function perform(action, value) {
    switch (action) {
      case 'digit': calc.inputDigit(value); break;
      case 'dot': calc.inputDot(); break;
      case 'operator': calc.inputOperator(value); break;
      case 'equals':
        calc.equals();
        save(HISTORY_KEY, JSON.stringify(calc.history));
        break;
      case 'clear': calc.clear(); break;
      case 'backspace': calc.backspace(); break;
      case 'percent': calc.percent(); break;
      case 'sign': calc.toggleSign(); break;
      default: return;
    }
    render();
  }

  keypad.addEventListener('click', (e) => {
    const btn = e.target.closest('.key');
    if (!btn) return;
    perform(btn.dataset.action, btn.dataset.value);
  });

  /* ---------- কিবোর্ড সাপোর্ট ---------- */
  function flash(selector) {
    const el = keypad.querySelector(selector);
    if (!el) return;
    el.classList.add('pressed');
    setTimeout(() => el.classList.remove('pressed'), 110);
  }

  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.key;

    if (/^[0-9]$/.test(k)) {
      perform('digit', k);
      flash(`[data-action="digit"][data-value="${k}"]`);
    } else if (k === '.' || k === ',') {
      perform('dot');
      flash('[data-action="dot"]');
    } else if (k === '+' || k === '-' || k === '*' || k === '/') {
      const map = { '+': '+', '-': '−', '*': '×', '/': '÷' };
      perform('operator', map[k]);
      flash(`[data-action="operator"][data-value="${map[k]}"]`);
      if (k === '/') e.preventDefault(); // ফায়ারফক্সের কুইক-ফাইন্ড ঠেকানো
    } else if (k === 'Enter' || k === '=') {
      e.preventDefault();
      perform('equals');
      flash('[data-action="equals"]');
    } else if (k === 'Backspace') {
      perform('backspace');
      flash('[data-action="backspace"]');
    } else if (k === 'Escape' || k === 'Delete') {
      if (!historyPanel.hidden) setHistoryOpen(false);
      else perform('clear');
      flash('[data-action="clear"]');
    } else if (k === '%') {
      perform('percent');
      flash('[data-action="percent"]');
    }
  });

  render();
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
}
